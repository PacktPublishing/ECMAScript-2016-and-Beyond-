export default class Greeter
{
    Hello(name)
    {
        return `Hello ${name} !!!`;
    }

    Bye(name)
    {
        return `Goodbye  ${name}`;
    }
}