import 'babel-polyfill';
import Greeter from './foo';

let  greeter = new Greeter();
document.getElementById("message").innerHTML = greeter.Hello('Lohith');
document.getElementById("message").innerHTML += "<br>" + greeter.Bye('Lohith');