var path = require('path');
var webpack = require('webpack');
var CopyWebpackPlugin = require('copy-webpack-plugin');

var dir_js = path.resolve(__dirname,'js');
var dir_html = path.resolve(__dirname,'html');
var dir_dist = path.resolve(__dirname,'dist');

module.exports = {
    entry:path.resolve(dir_js,'main.js'),
    output:{
        path:dir_dist,
        filename:'bundle.js'
    },
    module:{
        loaders:[
            {
                loader:'babel-loader',
                test:dir_js
            }
        ]
    },
    plugins:[
        new CopyWebpackPlugin([
            {from:dir_html}
        ])
    ],
    devtool:'source-map',
    devServer:{
        contentBase:dir_dist
    },
    stats:{
        colors:true
    }
}