let mysq = n => n*n;
console.log(mysq(5));