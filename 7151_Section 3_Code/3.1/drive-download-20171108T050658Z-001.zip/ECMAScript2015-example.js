class Circle
{
    constructor(radius)
    {
        this.radius = radius;
    } 

    area()
    {
        let area = 2 * Math.PI + this.radius;
        console.log(`Radius:${this.radius} - Area:${area}`);
        return area;
    }
} 

let circle = new Circle(5);
console.log(circle.area());